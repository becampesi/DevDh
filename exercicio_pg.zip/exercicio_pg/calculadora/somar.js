// Declaração da função somar
// 1° Parâmetro => 1 número a ser somado
// 2° Parâmetro => 2 número a ser somado
function somar(numero1, numero2){
  const resultado = numero1 + numero2;
  // retorna a soma dos dois números
  return resultado;
}

// Exportação da função somar
module.exports = somar;