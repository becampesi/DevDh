// Declaração da função subtrair
// 1° Parâmetro => 1 número a ser subtraido
// 2° Parâmetro => 2 número a ser subtraido
function subtrair(numero1, numero2){
  const resultado = numero1 - numero2;
  // retorna a subtração dos dois números
  return resultado;
}

// Exportação da função somar
module.exports = subtrair;